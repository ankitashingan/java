package com.jbk.Controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jbk.DAO.LoginDAO;
import com.jbk.DAO.QuestionDAO;
import com.jbk.entity.Answer;
import com.jbk.entity.Question;
import com.jbk.entity.User;

@Controller
public class LoginController {

	@Autowired
	LoginDAO dao;
	
	@Autowired
	QuestionDAO qdao;
	
	@RequestMapping("/logins")
	public String login() {
		
		return "login";
	}
	
	
	@RequestMapping("/")
	public String home() {
		
		return "menu";
	}
	
	@RequestMapping("admin")
	public String questionmanagement() {
		
		return "questionmanagement";
	}
	
	@RequestMapping("login")
	public ModelAndView validate(String username,String password,String subject,HttpServletRequest request)
	{
		
		HttpSession httpsession=request.getSession();
		
		User user=dao.getUser(username);
		
		ModelAndView modelandview=new ModelAndView();
		
		if(user==null) {
			
			modelandview.setViewName("login");;
			
			modelandview.addObject("message","Cheack your username");
			
		
		}
		    else if(user.getPassword().equals(password))
		{
	     	modelandview.setViewName("Question");
			
			modelandview.addObject("message","Start Exam");
			
			modelandview.addObject("photo",user.getImagepath());
			
			List<Question> list =qdao.getAllQuestions(subject);
		
			//if only one que is print then use get method
			Question question=list.get(0);
		
			httpsession.setAttribute("question", question);
			httpsession.setAttribute("questions", list);
			httpsession.setAttribute("username", username);
			httpsession.setAttribute("qno", 0);
			
			httpsession.setAttribute("score", 0);
			
			
			HashMap<Integer, Answer> hashmap=new HashMap<>();
			
			httpsession.setAttribute("submittedDetails", hashmap);
			
			System.out.println(question);
		}
		else
		{
			modelandview.setViewName("login");
			
			modelandview.addObject("message","wrong password");
			
		}
		    return modelandview;
	}
	   
	
	
	public ModelAndView logout(HttpServletRequest request) {
		
	    
	    HttpSession httpsession=request.getSession();
		
		System.out.println(httpsession.getAttribute("message"));
		
		httpsession.invalidate();
		
		ModelAndView modelandview=new ModelAndView();
		
		modelandview.addObject("message","session expired");
		
		modelandview.setViewName("login");
		
		return modelandview;
	}
}
