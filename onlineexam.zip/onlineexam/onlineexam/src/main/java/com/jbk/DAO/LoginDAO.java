package com.jbk.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jbk.entity.User;

@Repository
public class LoginDAO {
	
	@Autowired
	SessionFactory factory;
	
	public User getUser(String username) {
		
		Session session=factory.openSession();
		
		User user=session.get(User.class, username);
		
		return user;
	}
// interfaces are used to expose to services provided by which class is going to offer
	// ex- driver interface
}
