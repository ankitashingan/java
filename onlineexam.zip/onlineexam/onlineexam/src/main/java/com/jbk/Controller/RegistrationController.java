package com.jbk.Controller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.jbk.DAO.RegistrationDAO;
import com.jbk.entity.User;


@Controller
public class RegistrationController {
	
	@Autowired
	  RegistrationDAO dao;
	
	@RequestMapping("register")
	
	  public String register() {
		
		return "register";
	}
	
	@RequestMapping("save")
	public  ModelAndView saveRegistration(User user,HttpServletRequest request) throws Exception{
		
		MultipartFile image=user.getImage();
		
		String filename=image.getOriginalFilename();
		
		String foldername=request.getServletContext().getRealPath("images");
		
		image.transferTo(new File(foldername,filename));
		
		user.setImagepath("/images/"+filename);
		
		dao.saveToDB(user);
		
		ModelAndView modelandview=new ModelAndView();
		
		
		modelandview.setViewName("login");
		
		modelandview.addObject("message","Registration successful..!!");
		
		return modelandview;
		
	}
	

}
