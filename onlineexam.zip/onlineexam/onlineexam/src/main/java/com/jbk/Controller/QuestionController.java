package com.jbk.Controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jbk.entity.Answer;
import com.jbk.entity.Question;


@Controller
public class QuestionController {
	
	@RequestMapping("endexam")
	public ModelAndView endexam(HttpServletRequest request) {
		
		ModelAndView modelandview=new ModelAndView();
		
		HttpSession httpsession= request.getSession();
		
		HashMap<Integer, Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		
		System.out.println(hashmap);
		
		if(hashmap==null) {
			 
			modelandview.setViewName("login");
			
			  return modelandview;
		}
		
		Collection<Answer> collection=hashmap.values();
		
		for(Answer answer:collection) {
			
			if(answer.getOption().equals(answer.getOriginalAnswer())) {
				
				httpsession.setAttribute("score",(Integer) httpsession.getAttribute("score")+1);
			}
			
		}
		
		modelandview.addObject("allanswers",collection);
		modelandview.setViewName("score");
		modelandview.addObject("score",(Integer) httpsession.getAttribute("score"));
		
		httpsession.invalidate();
		
		return modelandview;
		
	}
	
	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request,Answer answer) {
		
		HttpSession httpsession=request.getSession();
		
		if(request.getParameter("option")!=null) {
			HashMap<Integer, Answer> hashmap= (HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		
			hashmap.put(answer.getQno(), answer);
			
			System.out.println(hashmap);
		
		}
		
		List<Question> list= (List<Question>)httpsession.getAttribute("questions");
		
		ModelAndView modelandview =new ModelAndView();
	
		modelandview.setViewName("Question");
		
		if((Integer)httpsession.getAttribute("qno")<=list.size()-2)
		
		{
			httpsession.setAttribute("qno", (Integer) httpsession.getAttribute("qno")+1);
			
			Question question=list.get((Integer) httpsession.getAttribute("qno"));
			
			modelandview.addObject("question",question);
			
		
		}
	     	else	
		{
	     		modelandview.addObject("question",list.get(list.size()-1));
			
	     		modelandview.addObject("message","End Exam");
			
		}
		    return modelandview;
	}
	
	@RequestMapping("previous")
	public ModelAndView previous(HttpServletRequest request) {
		
		HttpSession httpsession =request.getSession();
		
		List<Question> list =(List<Question>) httpsession.getAttribute("questions");
	
		ModelAndView modelandview=new ModelAndView();
		
		modelandview.setViewName("Question");
		
		if((Integer)httpsession.getAttribute("qno")>0)
		{
			httpsession.setAttribute("qno",(Integer) httpsession.getAttribute("qno")-1);
		
			Question question=list.get((Integer) httpsession.getAttribute("qno"));
			
			
			// code to retrieve previous answer

			int qno=question.getQno(); // retrieve question number
					
			HashMap<Integer, Answer>  hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
			
			
			Answer answer=hashmap.get(qno);
			
			String previousAnswer="";
			
			if(answer!=null)
			{
				previousAnswer=answer.getOption();
			}
			
			
			modelandview.addObject("question",question);
			
			modelandview.addObject("previousAnswer",previousAnswer);
			
		}
		else
		{
			modelandview.addObject("message","Start Exam");
				
			modelandview.addObject("question",list.get(0));
		
		}
		
		return modelandview;
	}
	
	

}
