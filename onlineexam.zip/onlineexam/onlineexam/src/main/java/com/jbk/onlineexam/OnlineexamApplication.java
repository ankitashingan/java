package com.jbk.onlineexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication

@ComponentScan("com")
@EntityScan("com")
public class OnlineexamApplication {

	
	public static void main(String[] args) {

		SpringApplication.run(OnlineexamApplication.class, args);
	
		//package java.lang
		//Object o=new Object();
		//o.clone();
		//protected member is available to all the classes from same package and in 
		//diffeerent package it is available to childclasses only and must be access using child class object only
	
		//ex- package com.jbk;
		// class Student{
		//main()method{
		//Object o=new Object();
		//o.clone();--error
	
	
	}
	
	

}
