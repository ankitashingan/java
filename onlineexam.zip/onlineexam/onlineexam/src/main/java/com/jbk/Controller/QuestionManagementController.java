package com.jbk.Controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jbk.entity.Question;
import com.jbk.Controller.*;



@Controller
public class QuestionManagementController {

	@Autowired
	SessionFactory factory;

	@RequestMapping("addQuestion")
	public ModelAndView addQuestion(Question questions)
	{
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
			session.save(questions);
		
		tx.commit(); // model-data which should be displayed on jsp page
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("questionmanagement");
		
		modelAndView.addObject("message","question addded");
		
		return modelAndView;
		
	}
	
	@RequestMapping("updateQuestion")
	public ModelAndView updateQuestion(Question questions)
	{
		Session session = factory.openSession();
		
		
		
		Transaction tx = session.beginTransaction();
		
		
		Query<Question> query=session.createQuery("update Question set  qtext=:qtext,op1=:op1,op2=:op2,op3=:op3,op4=:op4,answer=:answer where qno=:qno and subject=:subject");
		
		
		query.setParameter("qno",questions.qno);
		query.setParameter("qtext", questions.qtext);
		query.setParameter("subject",questions.subject);
		query.setParameter("op1",questions.op1);
		query.setParameter("op2",questions.op2);
		query.setParameter("op3",questions.op3);
		query.setParameter("op4",questions.op4);
		query.setParameter("answer",questions.answer);
		
		query.executeUpdate();
			
		
		tx.commit(); // model-data which should be displayed on jsp page
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("questionmanagement");
		
		modelAndView.addObject("message","question updated");
		
		return modelAndView;
		
	}
	
	
	@RequestMapping("viewQuestion")
	public ModelAndView viewQuestion(Integer qno,String subject)
	{
		Session session = factory.openSession();
		
		// session.load(Student.class,qno)
		
		Query<Question> query=session.createQuery("from Question where qno=:qno and subject=:subject");
		query.setParameter("qno",qno);
		query.setParameter("subject",subject);
		
		List<Question> list=query.list();
		
		Question question=list.get(0);
		
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("questionmanagement");
		modelAndView.addObject("question",question);
		
		
		return modelAndView;
	}
	
	
	
// delete from questions where qno=1 and subject='maths'
	
	@RequestMapping("deleteQuestion")
	public ModelAndView deleteQuestion(Question questions)
	{
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		Query<Question> query=session.createQuery("delete from Question  where qno=:qno and subject=:subject");
		
		query.setParameter("qno",questions.qno);
		query.setParameter("subject",questions.subject);
		
		query.executeUpdate();
		
		tx.commit();
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("questionmanagement");
		
		modelAndView.addObject("message","question deleted");
		
		return modelAndView;
		
		
	}
	
}
