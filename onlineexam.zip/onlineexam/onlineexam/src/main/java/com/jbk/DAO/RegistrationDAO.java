package com.jbk.DAO;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jbk.entity.User;


@Repository
public class RegistrationDAO {
	
	
	@Autowired
	SessionFactory factory;
	
	public void saveToDB(User user) {
		
		Session session =factory.openSession();
		
		Transaction tx=session.beginTransaction();
		
		session.save(user);
		
		tx.commit();
	}
	
	//implicit object in jsp-object which are automatically created are called implicit object e.g. 
	//e.g.httpservlet request object is created automatically by server 
	//system.out.println out is reference of printstream class
	
	

}
