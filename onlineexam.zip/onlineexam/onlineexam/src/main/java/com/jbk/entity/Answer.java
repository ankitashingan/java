package com.jbk.entity;

public class Answer {
	
	int qno;
	String qtext;
	String option,originalAnswer;
	
	
	public int getQno() {
		return qno;
	}
	public void setQno(int qno) {
		this.qno = qno;
	}
	public String getQtext() {
		return qtext;
	}
	public void setQtext(String qtext) {
		this.qtext = qtext;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getOriginalAnswer() {
		return originalAnswer;
	}
	public void setOriginalAnswer(String originalAnswer) {
		this.originalAnswer = originalAnswer;
	}
	@Override
	public String toString() {
		return "Answer [qno=" + qno + ", qtext=" + qtext + ", option=" + option + ", originalAnswer=" + originalAnswer
				+ "]";
	}
	
	
	

}
